﻿using System.Windows.Controls;

namespace LauncherNew.Views.Pages;

public partial class SettingsPage : Page
{
    public SettingsPage()
    {
        InitializeComponent();
    }
    
}