﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Media;
using LauncherNew.ViewModels;

namespace LauncherNew.Views.Pages
{
    public partial class ProfilePage : Page
    {
        private readonly Storyboard _cursorStoryboard;
        private readonly TranslateTransform _cursorTransform;
        private readonly MediaPlayer _mediaPlayer;

        public ProfilePage(long telegramId)
        {
            Console.WriteLine($"Начало вызова конструктора ProfilePage с Telegram ID: {telegramId}.");

            try
            {
                InitializeComponent();
                Console.WriteLine("InitializeComponent выполнен успешно.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при вызове InitializeComponent: {ex.Message}");
                throw;
            }

            try
            {
                Console.WriteLine($"Перед установкой DataContext с Telegram ID: {telegramId}");
                DataContext = new ProfileViewModel(telegramId);
                Console.WriteLine("DataContext успешно установлен.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при установке DataContext: {ex.Message}");
                throw;
            }

            
        }

        // Обработчик движения мыши
        private void UpdateMousePointerPosition(object sender, EventArgs e)
        {
            var position = Mouse.GetPosition(this);
            _cursorTransform.X = position.X - 16;
            _cursorTransform.Y = position.Y - 16;
        }

        private void PlayHoverSound(object sender, MouseEventArgs e)
        {
            PlaySound("C:\\Users\\lozik\\source\\repos\\LauncherNew\\LauncherNew\\Views\\Resources\\hover.mp3");
        }

        private void StopHoverSound(object sender, MouseEventArgs e)
        {
            _mediaPlayer.Stop();
        }

        private void PlayPortalSound(object sender, MouseEventArgs e)
        {
            PlaySound("C:\\Users\\lozik\\source\\repos\\LauncherNew\\LauncherNew\\Views\\Resources\\portal.mp3");
        }

        private void StopPortalSound(object sender, MouseEventArgs e)
        {
            _mediaPlayer.Stop();
        }

        private void PlaySound(string soundPath)
        {
            try
            {
                if (!System.IO.File.Exists(soundPath))
                {
                    MessageBox.Show($"Файл звука не найден: {soundPath}");
                    return;
                }

                _mediaPlayer.Open(new Uri(soundPath, UriKind.Absolute));
                _mediaPlayer.MediaEnded += (s, ev) =>
                {
                    _mediaPlayer.Position = TimeSpan.Zero;
                    _mediaPlayer.Play();
                };
                _mediaPlayer.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка воспроизведения звука: {ex.Message}");
            }
        }

        private void UpperPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Window.GetWindow(this)?.DragMove();
            }
        }

        private void LauncherHideButton_Click(object sender, RoutedEventArgs e)
        {
            ((ProfileViewModel)Application.Current.MainWindow.DataContext).HideLauncher();
        }

        private void LauncherCloseButton_Click(object sender, RoutedEventArgs e)
        {
            ((ProfileViewModel)Application.Current.MainWindow.DataContext).CloseLauncher();
        }
        

        private void SettingsOpenButton_Click(object sender, RoutedEventArgs e)
        {
            ((MainViewModel)Application.Current.MainWindow.DataContext).ShowSettings();
        }

       
    }
}
