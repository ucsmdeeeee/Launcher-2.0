﻿using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Media;
using LauncherNew.ViewModels;

namespace LauncherNew.Views.Pages
{
    public partial class DashboardPage : Page
    {
        private readonly Storyboard _cursorStoryboard;
        private readonly TranslateTransform _cursorTransform;

        public DashboardPage(long telegramId)
        {
            Console.WriteLine($"Начало вызова конструктора DashboardPage с Telegram ID: {telegramId}.");

            try
            {
                InitializeComponent();
                Console.WriteLine("InitializeComponent выполнен успешно.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при вызове InitializeComponent: {ex.Message}");
                throw;
            }

            try
            {
                Console.WriteLine($"Перед установкой DataContext с Telegram ID: {telegramId}");
                // Убедитесь, что передаете telegramId в ViewModel
                DataContext = new DashboardViewModel(new MainViewModel(), telegramId);
                Console.WriteLine("DataContext успешно установлен.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при установке DataContext: {ex.Message}");
                throw;
            }

            CompositionTarget.Rendering += UpdateMousePointerPosition;
            _cursorTransform = new TranslateTransform();
            MousePointer.RenderTransform = _cursorTransform;

            // Создание анимации для плавного перемещения курсора
            _cursorStoryboard = new Storyboard();
            DoubleAnimation xAnimation = new DoubleAnimation
            {
                Duration = TimeSpan.FromMilliseconds(50),
                AccelerationRatio = 0.5,
                DecelerationRatio = 0.5
            };
            Storyboard.SetTarget(xAnimation, MousePointer);
            Storyboard.SetTargetProperty(xAnimation, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.X)"));

            DoubleAnimation yAnimation = new DoubleAnimation
            {
                Duration = TimeSpan.FromMilliseconds(50),
                AccelerationRatio = 0.5,
                DecelerationRatio = 0.5
            };
            Storyboard.SetTarget(yAnimation, MousePointer);
            Storyboard.SetTargetProperty(yAnimation, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)"));

            _cursorStoryboard.Children.Add(xAnimation);
            _cursorStoryboard.Children.Add(yAnimation);
        }


        // Обработчик MouseMove
        private void UpdateMousePointerPosition(object sender, EventArgs e)
        {
            Point position = Mouse.GetPosition(this);

            // Обновление позиции TranslateTransform напрямую
            _cursorTransform.X = position.X - 16;
            _cursorTransform.Y = position.Y - 16;
        }
        
        private MediaPlayer _mediaPlayer = new MediaPlayer();

        private void PlayHoverSound(object sender, MouseEventArgs e)
        {
            try
            {
                string soundPath = "C:\\Users\\lozik\\source\\repos\\LauncherNew\\LauncherNew\\Views\\Resources\\hover.mp3";

                if (!System.IO.File.Exists(soundPath))
                {
                    MessageBox.Show($"Файл звука не найден: {soundPath}");
                    return;
                }

                // Установка пути к файлу и включение повтора
                _mediaPlayer.Open(new Uri(soundPath, UriKind.Absolute));
                _mediaPlayer.MediaEnded += (s, ev) =>
                {
                    _mediaPlayer.Position = TimeSpan.Zero; // Сброс к началу
                    _mediaPlayer.Play(); // Повтор воспроизведения
                };

                _mediaPlayer.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка воспроизведения звука: {ex.Message}");
            }
        }

        private void StopHoverSound(object sender, MouseEventArgs e)
        {
            try
            {
                _mediaPlayer.Stop(); // Остановка воспроизведения
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка остановки звука: {ex.Message}");
            }
        }

        private void PlayPortalSound(object sender, MouseEventArgs e)
        {
            try
            {
                string soundPath = "C:\\Users\\lozik\\source\\repos\\LauncherNew\\LauncherNew\\Views\\Resources\\portal.mp3";

                if (!System.IO.File.Exists(soundPath))
                {
                    MessageBox.Show($"Файл звука не найден: {soundPath}");
                    return;
                }

                // Установка пути к файлу и включение повтора
                _mediaPlayer.Open(new Uri(soundPath, UriKind.Absolute));
                _mediaPlayer.MediaEnded += (s, ev) =>
                {
                    _mediaPlayer.Position = TimeSpan.Zero; // Сброс к началу
                    _mediaPlayer.Play(); // Повтор воспроизведения
                };

                _mediaPlayer.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка воспроизведения звука: {ex.Message}");
            }
        }

        private void StopPortalSound(object sender, MouseEventArgs e)
        {
            try
            {
                _mediaPlayer.Stop(); // Остановка воспроизведения
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка остановки звука: {ex.Message}");
            }
        }
        
        private void UpperPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                // Получаем главное окно и вызываем DragMove
                Window.GetWindow(this)?.DragMove();
            }
        }

        private void StartGameButton_Click(object sender, RoutedEventArgs e)
        {
            ((DashboardViewModel)this.DataContext).LaunchMinecraft();
        }

        private void LauncherHideButton_Click(object sender, RoutedEventArgs e)
        {
            ((DashboardViewModel)this.DataContext).HideLauncher();
        }
        private void ShopShowButton_Click(object sender, RoutedEventArgs e)
        {
            long telegramId = ((ShopViewModel)this.DataContext).TelegramId; // Fetch telegramId from ViewModel
            ((MainViewModel)Application.Current.MainWindow.DataContext).ShowShop(telegramId);
            
        }

        private void LauncherCloseButton_Click(object sender, RoutedEventArgs e)
        {
            ((DashboardViewModel)this.DataContext).CloseLauncher();
        }
        private void SettingsOpenButton_Click(object sender, RoutedEventArgs e)
        {
            ((MainViewModel)Application.Current.MainWindow.DataContext).ShowSettings();
        }
    }
}