﻿using System;
using System.Threading.Tasks;
using Dapper;
using LauncherNew.Models;
using Npgsql;

namespace LauncherNew
{
    public class Database
    {
        private readonly string _connectionString;

        public Database(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Получение данных пользователя по tg_id
        public async Task<User> GetUserByTelegramIdAsync(long telegramId)
        {
            const string query = "SELECT * FROM \"User\" WHERE \"tg_id\" = @telegramId";

            Console.WriteLine($"Executing query: {query} with telegramId: {telegramId}");

            using var connection = new NpgsqlConnection(_connectionString);
            await connection.OpenAsync();

            try
            {
                var user = await connection.QueryFirstOrDefaultAsync<User>(query, new { telegramId });
                return user; // Возвращаем найденного пользователя
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error executing query: {ex.Message}");
                return null; // Возвращаем null в случае ошибки
            }
        }
    }
}