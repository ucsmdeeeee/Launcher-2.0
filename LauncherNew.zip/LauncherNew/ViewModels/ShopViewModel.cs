﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using MvvmCross.ViewModels;
using LauncherNew.Models;

namespace LauncherNew.ViewModels;

public class ShopViewModel : MvxViewModel, INotifyPropertyChanged
    {
        private ObservableCollection<Item> _displayedItems;
        public ObservableCollection<Item> DisplayedItems
        {
            get => _displayedItems;
            set
            {
                _displayedItems = value;
                OnPropertyChanged(nameof(DisplayedItems));
            }
        }



    public ObservableCollection<Item> Items { get; set; }
        public ObservableCollection<Item> SelectedItems { get; set; }

        private int _totalPrice;
        public int TotalPrice
        {
            get => _totalPrice;
            set
            {
                _totalPrice = value;
                OnPropertyChanged(nameof(TotalPrice));
            }
        }

        private int _balance = 1000; // Начальный баланс
        public int Balance
        {
            get => _balance;
            set
            {
                _balance = value;
                OnPropertyChanged(nameof(Balance));
            }
        }
        private long _telegramId;

        public long TelegramId
        {
            get => _telegramId;
            set
            {
                _telegramId = value;
                OnPropertyChanged(nameof(TelegramId));
            }
        }


        public ICommand AddToCartCommand { get; }
        public ICommand PurchaseCommand { get; }

        public ShopViewModel()
        {
            Items = new ObservableCollection<Item>();
            DisplayedItems = new ObservableCollection<Item>();
            SelectedItems = new ObservableCollection<Item>();

            AddToCartCommand = new RelayCommand<Item>(AddToCart);
            PurchaseCommand = new RelayCommand<object>(_ => PurchaseItems());

            PopulateGrid(); // Заполняем Items, но не DisplayedItems
            
        }

        public void FilterItemsByCategory(string category)
        {
            if (string.IsNullOrEmpty(category)) return;

            // Проверяем, что Items и DisplayedItems не null
            if (Items == null || DisplayedItems == null)
            {
                Debug.WriteLine("Items или DisplayedItems не инициализированы.");
                return;
            }

            // Очищаем DisplayedItems и фильтруем
            DisplayedItems.Clear();
            foreach (var item in Items.Where(i => i.Category == category))
            {
                DisplayedItems.Add(item);
            }
        }



        public void PopulateGrid()
        {
            Items.Add(new Item
            {
                Name = "Меч",
                ImagePath = "pack://application:,,,/Views/Resources/axe.png",
                Price = 100,
                Category = "Оружие"
            });

            Items.Add(new Item
            {
                Name = "Щит",
                ImagePath = "pack://application:,,,/Views/Resources/axe.png",
                Price = 150,
                Category = "Броня"
            });

            Items.Add(new Item
            {
                Name = "Дуб",
                ImagePath = "pack://application:,,,/Views/Resources/axe.png",
                Price = 50,
                Category = "Блоки"
            });

            Items.Add(new Item
            {
                Name = "Яблоко",
                ImagePath = "pack://application:,,,/Views/Resources/axe.png",
                Price = 10,
                Category = "Еда"
            });

            // `DisplayedItems` остаётся пустым
            DisplayedItems.Clear();
        }

        

        public void AddToCart(Item item)
        {
            if (item == null) return;

            var existingItem = SelectedItems.FirstOrDefault(x => x.Name == item.Name);

            if (existingItem != null)
            {
                // Проверяем максимальное количество
                if (existingItem.Category == "Инструменты" || existingItem.Category == "Броня" || existingItem.Category == "Оружие")
                {
                    MessageBox.Show("Максимальное количество для этого предмета: 1");
                    return;
                }

                if (existingItem.Quantity >= 64)
                {
                    MessageBox.Show("Максимальное количество для этого предмета: 64");
                    return;
                }
                
                existingItem.Quantity++;
                var index = SelectedItems.IndexOf(existingItem);
                SelectedItems[index] = null; // Временно очищаем
                SelectedItems[index] = existingItem; // Вставляем обновленный элеме
            }
            else
            {
                SelectedItems.Add(new Item
                {
                    Name = item.Name,
                    Price = item.Price,
                    ImagePath = item.ImagePath,
                    Category = item.Category,
                    Quantity = 1
                });
            }

            TotalPrice += item.Price;
        }
        
        public ICommand RemoveFromCartCommand => new RelayCommand<Item>(RemoveFromCart);

        private void RemoveFromCart(Item item)
        {
            if (item == null) return;

            // Ищем предмет в корзине
            var existingItem = SelectedItems.FirstOrDefault(x => x.Name == item.Name);

            if (existingItem != null)
            {
                // Уменьшаем количество
                existingItem.Quantity--;

                // Если количество стало 0, удаляем предмет
                if (existingItem.Quantity <= 0)
                {
                    SelectedItems.Remove(existingItem);
                }
                else
                {
                    // Обновляем элемент в коллекции
                    var index = SelectedItems.IndexOf(existingItem);
                    SelectedItems[index] = null;
                    SelectedItems[index] = existingItem;
                }

                // Обновляем общую стоимость
                TotalPrice -= item.Price;
                OnPropertyChanged(nameof(TotalPrice));
            }
        }


        private void PurchaseItems()
        {
            if (Balance < TotalPrice)
            {
                MessageBox.Show("Недостаточно средств!");
                return;
            }

            // Сериализация данных о покупке
            var purchaseData = new
            {
                Items = SelectedItems.Select(item => new
                {
                    item.Name,
                    item.Price,
                    item.Quantity,
                    item.Category
                }),
                TotalPrice,
                BalanceBefore = Balance,
                BalanceAfter = Balance - TotalPrice,
                Date = DateTime.Now
            };

            // Настройка сериализатора для сохранения оригинального текста
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            // Преобразование в JSON
            string json = JsonSerializer.Serialize(purchaseData, options);

            // Запись в консоль
            Console.WriteLine("Purchase Complete:");
            Console.WriteLine(json);

            // Завершение покупки
            Balance -= TotalPrice;
            SelectedItems.Clear();
            TotalPrice = 0;

            // Уведомляем об изменениях
            OnPropertyChanged(nameof(Balance));
            OnPropertyChanged(nameof(TotalPrice));
        }



        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    
        

        public async Task HideLauncher()
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Application.Current.MainWindow.WindowState = WindowState.Minimized;
            });
        }

        public async Task CloseLauncher()
        {
            Application.Current.Dispatcher.Invoke(() => { Application.Current.MainWindow.Close(); });
        }

        
    }
public class RelayCommand<T> : ICommand
{
    private readonly Action<T> _execute;
    private readonly Predicate<T> _canExecute;

    public RelayCommand(Action<T> execute, Predicate<T> canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    public bool CanExecute(object parameter) => _canExecute == null || _canExecute((T)parameter);

    public void Execute(object parameter) => _execute((T)parameter);

    public event EventHandler CanExecuteChanged
    {
        add => CommandManager.RequerySuggested += value;
        remove => CommandManager.RequerySuggested -= value;
    }
}



