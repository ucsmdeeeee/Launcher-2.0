﻿namespace LauncherNew.ViewModels;

public class SettingsViewModel
{
    
}