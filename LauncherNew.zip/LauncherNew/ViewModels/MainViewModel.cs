﻿using System.Windows.Controls;
using LauncherNew.Views.Pages;
using MvvmCross.ViewModels;

namespace LauncherNew.ViewModels;

public class MainViewModel:MvxViewModel
{
    private Page _dashboardPage;
    private Page _shopPage;
    private Page _settingsPage = new SettingsPage();
    private Page _profilePage;


    private Page _currentPage;

    public Page CurrentPage
    {
        get => _currentPage;
        set => SetProperty(ref _currentPage, value);
    }

    public MainViewModel()
    {
        CurrentPage = new Views.Pages.AuthorizationPage();
    }

    public void ShowLauncher(long telegramId)
    {
        _dashboardPage = new DashboardPage(telegramId); // Передаем telegramId
        CurrentPage = _dashboardPage;
    }
    
    public void ShowShop(long telegramId)
    {
        _shopPage = new ShopPage(telegramId); // Передаем telegramId
        CurrentPage = _shopPage;
    }


    public void ShowSettings()
    {
        CurrentPage = _settingsPage;
    }
    
    public void ShowProfile(long telegramId)
    {
        _profilePage = new ProfilePage(telegramId); // Передаем telegramId
        CurrentPage = _profilePage;
    }
    
}