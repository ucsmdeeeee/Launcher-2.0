﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using MvvmCross.ViewModels;
using LauncherNew.Models;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.Version;
using CmlLib.Core.VersionLoader;
using CmlLib.Utils;
using LauncherNew.ViewModels;
using LauncherNew.Views.Pages;

namespace LauncherNew.ViewModels;

public class DashboardViewModel : MvxViewModel, INotifyPropertyChanged
{
    private readonly CMLauncher _launcher;
    private readonly MinecraftPath _minecraftPath = new MinecraftPath();
    private readonly Database _database;  // Инициализация базы данных
    private readonly MainViewModel _mainViewModel;
    private readonly long _telegramId; // Сохраняем telegramId

    // Свойства и события
    public event PropertyChangedEventHandler PropertyChanged;

    public int RAM { get; set; }
    public int ProgressPercentage { get; set; }
    public string LoadingStatus { get; set; }
    public bool IsLoadingVisible { get; set; }
    public double ProgressBarWidth => (ProgressPercentage / 100.0) * 200.0;

    // Конструктор с передачей telegramId
    public DashboardViewModel(MainViewModel mainViewModel, long telegramId)
    {
        _mainViewModel = mainViewModel;
        _telegramId = telegramId;  // Сохраняем telegramId
        _launcher = new CMLauncher(_minecraftPath);
        _database = new Database("Host=93.158.195.13;Port=5432;Username=postgres;Password=1548;Database=students");
        if (_database == null)
        {
            throw new Exception("База данных не инициализирована.");
        }
       
    }

    

    public long TelegramId => _telegramId; // Возвращаем telegramId
    // Метод запуска Minecraft
    public async Task LaunchMinecraft()
    {
        try
        {
            IsLoadingVisible = true;
            System.Net.ServicePointManager.DefaultConnectionLimit = 256;

            LoadingStatus = "Инициализация лаунчера...";
            ProgressPercentage = 10;
            var versionToLaunch = "1.19";

            await Task.Delay(2000);
            LoadingStatus = "Подготовление версии Майнкрафт...";
            ProgressPercentage = 30;

            // Получаем nickname из базы данных по telegramId
            if (_database == null)
            {
                Console.WriteLine("Ошибка: _database не инициализирован.");
                return;
            }

            var user = await _database.GetUserByTelegramIdAsync(_telegramId);
// Здесь telegramId - ваш идентификатор пользователя
            if (user == null)
            {
                throw new Exception("Пользователь не найден в базе данных.");
            }

            var nickname = user.Nickname; // Предположим, что у вас есть свойство Nickname

            LoadingStatus = $"Загрузка версии {versionToLaunch}...";
            ProgressPercentage = 50;
            var launchOption = new MLaunchOption
            {
                MaximumRamMb = 4000,
                Session = MSession.GetOfflineSession(nickname), // Передаем nickname в метод GetOfflineSession
            };
            await Task.Delay(2000);
            LoadingStatus = "Создание процессов...";
            ProgressPercentage = 70;
            var processInfo = await _launcher.CreateProcessAsync(versionToLaunch, launchOption);

            await Task.Delay(2000);
            LoadingStatus = "Подготовления к запуску...";
            ProgressPercentage = 90;
            var process = processInfo.Start();

            LoadingStatus = "Запуск, приятной игры!";
            ProgressPercentage = 99;

            // Скрываем прогресс-бар через 3 секунды
            await Task.Delay(15000);
            ProgressPercentage = 100;
            await Task.Delay(10000);
            IsLoadingVisible = false;
        }
        catch (Exception ex)
        {
            LoadingStatus = "Error: " + ex.Message;
            ProgressPercentage = 0;
            IsLoadingVisible = true; // Оставляем видимость для ошибки
            Debug.WriteLine("Error launching Minecraft: " + ex.Message);
        }
    }

    public async Task HideLauncher()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        });
    }

    public async Task CloseLauncher()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            Application.Current.MainWindow.Close();
        });
    }

    public void ShowShop()
    {
        // Меняем ContentPage на новую страницу
        _mainViewModel.CurrentPage = new ShopPage(_telegramId);
    }

    public async void ShowSetting()
    {
        _mainViewModel.CurrentPage = new SettingsPage();
    }
}
